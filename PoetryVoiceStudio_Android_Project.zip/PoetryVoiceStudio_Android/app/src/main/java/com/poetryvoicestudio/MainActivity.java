package com.poetryvoicestudio;
import android.app.*;import android.os.*;import android.content.*;import android.graphics.Color;import android.speech.tts.*;import android.view.*;import android.widget.*;import java.util.*;
public class MainActivity extends Activity implements TextToSpeech.OnInitListener{
 TextToSpeech tts; EditText poem,instr; Spinner voice; SeekBar speed,pitch; Spinner pause; TextView status;
 public void onCreate(Bundle b){super.onCreate(b); tts=new TextToSpeech(this,this); build();}
 TextView tv(String s){TextView v=new TextView(this);v.setText(s);v.setTextColor(Color.WHITE);v.setTextSize(16);v.setPadding(0,12,0,6);return v;}
 EditText ed(String s,int h){EditText e=new EditText(this);e.setText(s);e.setTextColor(Color.WHITE);e.setHintTextColor(Color.GRAY);e.setBackgroundColor(Color.rgb(25,27,32));e.setGravity(Gravity.TOP);e.setPadding(14,12,14,12);e.setMinHeight(h);return e;}
 void build(){ScrollView sc=new ScrollView(this); LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(18,18,18,18);l.setBackgroundColor(Color.rgb(16,17,20));
 l.addView(tv("🎙️  Poetry Voice Studio"));l.addView(tv("اردو، پشتو، ہندی اور English کے لیے اپنی آواز تیار کریں"));
 l.addView(tv("شاعری / متن"));poem=ed("وہ میرا نہیں ہوگا، یہ معلوم تھا مجھے،\nمگر اُس کی جدائی کا دل کو ملال تھا۔\n\nانجامِ محبت کا مجھے خوب اندازہ تھا،\nپھر بھی دل کو اُسی شخص کا انتظار تھا۔\n\nوہ شخص بھی عجیب تھا، دل سے کبھی نکلا نہیں،\nاور ہم بھی پاگل تھے… اُس کا انتظار ختم ہوا نہیں۔",190);l.addView(poem);
 l.addView(tv("آواز"));voice=new Spinner(this);l.addView(voice);
 l.addView(tv("آواز کس طرح پڑھنی ہے؟"));instr=ed("آواز گہری، سنجیدہ اور اداس ہو۔\nرفتار آہستہ اور قدرتی رکھیں۔\nمحبت، جدائی اور انتظار کا احساس واضح ہو لیکن زیادہ ڈرامائی نہ ہو۔\nہر شعر کے بعد تقریباً 1.5 سیکنڈ کا وقفہ دیں۔\nآخری لائنیں زیادہ دل سے اور قدرے دھیمی آواز میں پڑھیں۔",150);l.addView(instr);
 l.addView(tv("رفتار"));speed=new SeekBar(this);speed.setMax(70);speed.setProgress(28);l.addView(speed);
 l.addView(tv("Pitch"));pitch=new SeekBar(this);pitch.setMax(80);pitch.setProgress(35);l.addView(pitch);
 l.addView(tv("وقفہ"));pause=new Spinner(this);String[] ps={"0.5 سیکنڈ","1 سیکنڈ","1.5 سیکنڈ","2 سیکنڈ","2.5 سیکنڈ"};pause.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,ps));pause.setSelection(2);l.addView(pause);
 LinearLayout row=new LinearLayout(this);Button play=new Button(this);play.setText("▶️ چلائیں");Button stop=new Button(this);stop.setText("⏹️ بند کریں");row.addView(play,new LinearLayout.LayoutParams(0,-2,1));row.addView(stop,new LinearLayout.LayoutParams(0,-2,1));l.addView(row);
 status=tv("تیار ہے۔");l.addView(status);sc.addView(l);setContentView(sc);
 play.setOnClickListener(v->speak());stop.setOnClickListener(v->{if(tts!=null)tts.stop();status.setText("رک گیا۔");});
 }
 public void onInit(int r){if(r==TextToSpeech.SUCCESS){loadVoices();tts.setLanguage(new Locale("ur","PK"));}}
 void loadVoices(){ArrayList<String> names=new ArrayList<>();for(Locale loc:tts.getAvailableLanguages()){if(loc.getLanguage().matches("ur|hi|ps|en"))names.add(loc.toLanguageTag());}if(names.size()==0)names.add("ur-PK");voice.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,names));}
 void speak(){String[] parts=poem.getText().toString().trim().split("\\n\\s*\\n");int i=0;float rate=.78f+speed.getProgress()*.006f;for(String p:parts){Bundle params=new Bundle();tts.speak(p,TextToSpeech.QUEUE_ADD,params,"p"+(i++));}status.setText("پڑھا جا رہا ہے…");}
 public void onDestroy(){if(tts!=null){tts.stop();tts.shutdown();}super.onDestroy();}
}