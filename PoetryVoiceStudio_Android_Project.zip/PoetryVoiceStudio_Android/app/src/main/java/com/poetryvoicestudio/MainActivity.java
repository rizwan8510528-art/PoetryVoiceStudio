package com.poetryvoicestudio;

import android.app.Activity;
import android.os.Bundle;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.content.ContentValues;
import android.content.Context;
import android.net.Uri;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import android.media.MediaPlayer;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {

    EditText poem;
    EditText apiKey;
    EditText styleCommand;

    Spinner voiceSpinner;
    SeekBar speed;
    SeekBar stability;
    SeekBar style;

    TextView status;

    Button play;
    Button stop;
    Button save;
    Button loadVoices;

    ArrayList<String> voiceIds = new ArrayList<>();
    ArrayList<String> voiceNames = new ArrayList<>();

    MediaPlayer player;

    String lastAudioPath = null;

    int bg = Color.rgb(16, 16, 22);
    int cardBg = Color.rgb(29, 29, 38);
    int text = Color.WHITE;
    int subText = Color.rgb(190, 190, 205);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        buildUI();

        status.setText("✓ تیار ہے — پہلے API Key ڈالیں");
    }

    private void buildUI() {

        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(bg);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(18, 18, 18, 24);

        scroll.addView(root);

        TextView heading = title("Poetry Voice Studio", 28);
        heading.setGravity(Gravity.CENTER);
        root.addView(heading);

        TextView subtitle = label(
                "قدرتی Urdu Voice • Pakistani Style • MP3",
                15
        );
        subtitle.setGravity(Gravity.CENTER);
        root.addView(subtitle);

        root.addView(space(12));

        // API KEY
        LinearLayout apiCard = card();

        apiCard.addView(title("🔑  ElevenLabs API Key", 18));

        apiKey = edit(
                "API Key یہاں paste کریں",
                false
        );

        apiKey.setInputType(
                android.text.InputType.TYPE_CLASS_TEXT |
                android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
        );

        apiCard.addView(apiKey);

        loadVoices = action(
                "🔄  Voices Load کریں",
                Color.rgb(70, 95, 160)
        );

        apiCard.addView(
                loadVoices,
                new LinearLayout.LayoutParams(-1, 55)
        );

        root.addView(apiCard);

        root.addView(space(10));

        // POETRY
        LinearLayout poemCard = card();

        poemCard.addView(title("📝  اپنی شاعری", 18));

        poem = edit(
                "یہاں اپنی اردو شاعری لکھیں...",
                true
        );

        poem.setGravity(Gravity.TOP | Gravity.RIGHT);
        poem.setTextSize(20);
        poem.setTypeface(Typeface.create("sans-serif", Typeface.NORMAL));
        poem.setMinHeight(230);

        poemCard.addView(poem);

        root.addView(poemCard);

        root.addView(space(10));

        // VOICE
        LinearLayout voiceCard = card();

        voiceCard.addView(title("🎙️  Voice", 18));

        voiceSpinner = new Spinner(this);

        ArrayList<String> first = new ArrayList<>();
        first.add("پہلے Voices Load کریں");

        voiceSpinner.setAdapter(
                new ArrayAdapter<String>(
                        this,
                        android.R.layout.simple_spinner_dropdown_item,
                        first
                )
        );

        voiceCard.addView(
                voiceSpinner,
                new LinearLayout.LayoutParams(-1, 55)
        );

        root.addView(voiceCard);

        root.addView(space(10));

        // STYLE
        LinearLayout styleCard = card();

        styleCard.addView(title("🎭  Voice Style / Command", 18));

        styleCommand = edit(
                "مثال: Deep, emotional, slow Pakistani Urdu poetry reading...",
                true
        );

        styleCommand.setText(
                "Deep, emotional, sad and natural Pakistani Urdu poetry reading. " +
                "Speak slowly and clearly. " +
                "Keep natural pauses between verses. " +
                "Do not sound robotic. " +
                "Express love, separation and waiting with subtle emotion."
        );

        styleCommand.setMinHeight(150);

        styleCard.addView(styleCommand);

        root.addView(styleCard);

        root.addView(space(10));

        // CONTROLS
        LinearLayout controls = card();

        controls.addView(title("🎚️  Voice Controls", 18));

        controls.addView(label("رفتار", 15));

        speed = new SeekBar(this);
        speed.setMax(50);
        speed.setProgress(15);
        controls.addView(speed);

        controls.addView(label("Stability", 15));

        stability = new SeekBar(this);
        stability.setMax(100);
        stability.setProgress(45);
        controls.addView(stability);

        controls.addView(label("Style / Expression", 15));

        style = new SeekBar(this);
        style.setMax(100);
        style.setProgress(35);
        controls.addView(style);

        root.addView(controls);

        root.addView(space(12));

        // BUTTONS
        LinearLayout buttons = new LinearLayout(this);
        buttons.setOrientation(LinearLayout.HORIZONTAL);
        buttons.setGravity(Gravity.CENTER);

        play = action(
                "▶  چلائیں",
                Color.rgb(105, 70, 175)
        );

        stop = action(
                "■  بند",
                Color.rgb(70, 70, 80)
        );

        LinearLayout.LayoutParams bp =
                new LinearLayout.LayoutParams(0, 58, 1);

        bp.setMargins(4, 4, 4, 4);

        buttons.addView(play, bp);
        buttons.addView(stop, bp);

        root.addView(buttons);

        save = action(
                "⬇  MP3 Downloads میں محفوظ کریں",
                Color.rgb(45, 125, 95)
        );

        LinearLayout.LayoutParams sp =
                new LinearLayout.LayoutParams(-1, 60);

        sp.setMargins(4, 8, 4, 4);

        root.addView(save, sp);

        root.addView(space(8));

        status = new TextView(this);
        status.setTextColor(Color.rgb(120, 220, 170));
        status.setTextSize(15);
        status.setGravity(Gravity.CENTER);
        status.setPadding(8, 12, 8, 12);

        root.addView(status);

        setContentView(scroll);

        loadVoices.setOnClickListener(
                v -> loadVoicesFromServer()
        );

        play.setOnClickListener(
                v -> generateAudio(false)
        );

        save.setOnClickListener(
                v -> generateAudio(true)
        );

        stop.setOnClickListener(
                v -> stopAudio()
        );
    }

    private void loadVoicesFromServer() {

        final String key = apiKey.getText().toString().trim();

        if (key.length() < 10) {
            status.setText("⚠ پہلے ElevenLabs API Key ڈالیں");
            return;
        }

        status.setText("● Voices تلاش کی جا رہی ہیں...");

        new Thread(() -> {

            try {

                URL url = new URL(
                        "https://api.elevenlabs.io/v1/voices"
                );

                HttpURLConnection con =
                        (HttpURLConnection) url.openConnection();

                con.setRequestMethod("GET");
                con.setRequestProperty(
                        "xi-api-key",
                        key
                );

                con.setRequestProperty(
                        "Accept",
                        "application/json"
                );

                con.setConnectTimeout(20000);
                con.setReadTimeout(30000);

                int response = con.getResponseCode();

                InputStream in;

                if (response >= 200 && response < 300) {
                    in = con.getInputStream();
                } else {
                    in = con.getErrorStream();
                }

                String result = readStream(in);

                if (response < 200 || response >= 300) {
                    throw new Exception(
                            "API Error " + response
                    );
                }

                JSONObject object =
                        new JSONObject(result);

                JSONArray voices =
                        object.getJSONArray("voices");

                voiceIds.clear();
                voiceNames.clear();

                for (int i = 0; i < voices.length(); i++) {

                    JSONObject v =
                            voices.getJSONObject(i);

                    String id =
                            v.optString("voice_id");

                    String name =
                            v.optString(
                                    "name",
                                    "Voice " + i
                            );

                    if (id.length() > 0) {
                        voiceIds.add(id);
                        voiceNames.add(name);
                    }
                }

                runOnUiThread(() -> {

                    ArrayAdapter<String> adapter =
                            new ArrayAdapter<>(
                                    MainActivity.this,
                                    android.R.layout.simple_spinner_dropdown_item,
                                    voiceNames
                            );

                    voiceSpinner.setAdapter(adapter);

                    status.setText(
                            "✓ " + voiceNames.size() +
                            " Voices مل گئی ہیں"
                    );
                });

            } catch (Exception e) {

                runOnUiThread(() ->
                        status.setText(
                                "⚠ Voices Load نہیں ہوئیں: " +
                                e.getMessage()
                        )
                );
            }

        }).start();
    }

    private void generateAudio(boolean saveToDownloads) {

        final String key =
                apiKey.getText().toString().trim();

        final String text =
                poem.getText().toString().trim();

        if (key.length() < 10) {
            status.setText(
                    "⚠ پہلے API Key ڈالیں"
            );
            return;
        }

        if (text.length() == 0) {
            status.setText(
                    "⚠ پہلے شاعری لکھیں"
            );
            return;
        }

        int position =
                voiceSpinner.getSelectedItemPosition();

        if (voiceIds.size() == 0 ||
                position < 0 ||
                position >= voiceIds.size()) {

            status.setText(
                    "⚠ پہلے Voices Load کریں اور Voice منتخب کریں"
            );

            return;
        }

        final String voiceId =
                voiceIds.get(position);

        final float rate =
                0.70f +
                (speed.getProgress() / 100.0f);

        final float stab =
                stability.getProgress() / 100.0f;

        final float styleValue =
                style.getProgress() / 100.0f;

        status.setText(
                saveToDownloads ?
                "● MP3 تیار کی جا رہی ہے..." :
                "● آواز تیار کی جا رہی ہے..."
        );

        play.setEnabled(false);
        save.setEnabled(false);

        new Thread(() -> {

            byte[] audio = null;

            try {

                JSONObject body =
                        new JSONObject();

                body.put(
                        "text",
                        preparePoetry(text)
                );

                body.put(
                        "model_id",
                        "eleven_multilingual_v2"
                );

                body.put(
                        "output_format",
                        "mp3_44100_128"
                );

                JSONObject settings =
                        new JSONObject();

                settings.put(
                        "stability",
                        stab
                );

                settings.put(
                        "similarity_boost",
                        0.78
                );

                settings.put(
                        "style",
                        styleValue
                );

                settings.put(
                        "use_speaker_boost",
                        true
                );

                settings.put(
                        "speed",
                        rate
                );

                body.put(
                        "voice_settings",
                        settings
                );

                URL url = new URL(
                        "https://api.elevenlabs.io/v1/text-to-speech/"
                                + voiceId
                );

                HttpURLConnection con =
                        (HttpURLConnection)
                                url.openConnection();

                con.setRequestMethod("POST");

                con.setDoOutput(true);

                con.setRequestProperty(
                        "xi-api-key",
                        key
                );

                con.setRequestProperty(
                        "Content-Type",
                        "application/json"
                );

                con.setRequestProperty(
                        "Accept",
                        "audio/mpeg"
                );

                con.setConnectTimeout(30000);
                con.setReadTimeout(120000);

                OutputStream out =
                        con.getOutputStream();

                out.write(
                        body.toString()
                                .getBytes("UTF-8")
                );

                out.flush();
                out.close();

                int response =
                        con.getResponseCode();

                if (response < 200 ||
                        response >= 300) {

                    InputStream err =
                            con.getErrorStream();

                    String message =
                            readStream(err);

                    throw new Exception(
                            "API Error " +
                            response +
                            " " +
                            message
                    );
                }

                audio =
                        readBytes(
                                con.getInputStream()
                        );

                if (audio == null ||
                        audio.length < 1000) {

                    throw new Exception(
                            "Audio خالی ہے"
                    );
                }

                final byte[] finalAudio =
                        audio;

                runOnUiThread(() -> {

                    if (saveToDownloads) {

                        boolean ok =
                                saveMp3(
                                        finalAudio
                                );

                        if (ok) {

                            status.setText(
                                    "✓ MP3 Downloads میں محفوظ ہو گئی"
                            );

                        } else {

                            status.setText(
                                    "⚠ MP3 محفوظ نہیں ہو سکی"
                            );
                        }

                    } else {

                        playAudio(
                                finalAudio
                        );

                        status.setText(
                                "▶ قدرتی آواز چل رہی ہے..."
                        );
                    }

                    play.setEnabled(true);
                    save.setEnabled(true);
                });

            } catch (Exception e) {

                runOnUiThread(() -> {

                    status.setText(
                            "⚠ مسئلہ: " +
                            e.getMessage()
                    );

                    play.setEnabled(true);
                    save.setEnabled(true);
                });
            }

        }).start();
    }

    private String preparePoetry(String input) {

        String[] lines =
                input.split("\\n");

        StringBuilder result =
                new StringBuilder();

        for (String line : lines) {

            String s =
                    line.trim();

            if (s.length() == 0) {

                result.append(". ");

            } else {

                result.append(s);

                if (!s.endsWith("۔") &&
                        !s.endsWith(".") &&
                        !s.endsWith("؟") &&
                        !s.endsWith("?")) {

                    result.append("۔");
                }

                result.append(" ");
            }
        }

        return result.toString().trim();
    }

    private boolean saveMp3(byte[] data) {

        try {

            String filename =
                    "PoetryVoice_" +
                    System.currentTimeMillis() +
                    ".mp3";

            if (Build.VERSION.SDK_INT >=
                    Build.VERSION_CODES.Q) {

                ContentValues values =
                        new ContentValues();

                values.put(
                        MediaStore.Audio.Media.DISPLAY_NAME,
                        filename
                );

                values.put(
                        MediaStore.Audio.Media.MIME_TYPE,
                        "audio/mpeg"
                );

                values.put(
                        MediaStore.Audio.Media.RELATIVE_PATH,
                        Environment.DIRECTORY_DOWNLOADS
                );

                values.put(
                        MediaStore.Audio.Media.IS_PENDING,
                        1
                );

                Uri uri =
                        getContentResolver()
                                .insert(
                                        MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                                        values
                                );

                if (uri == null) {
                    return false;
                }

                OutputStream out =
                        getContentResolver()
                                .openOutputStream(uri);

                if (out == null) {
                    return false;
                }

                out.write(data);
                out.flush();
                out.close();

                ContentValues done =
                        new ContentValues();

                done.put(
                        MediaStore.Audio.Media.IS_PENDING,
                        0
                );

                getContentResolver().update(
                        uri,
                        done,
                        null,
                        null
                );

                return true;

            } else {

                File dir =
                        Environment.getExternalStoragePublicDirectory(
                                Environment.DIRECTORY_DOWNLOADS
                        );

                if (!dir.exists()) {
                    dir.mkdirs();
                }

                File file =
                        new File(dir, filename);

                FileOutputStream out =
                        new FileOutputStream(file);

                out.write(data);
                out.flush();
                out.close();

                return true;
            }

        } catch (Exception e) {

            return false;
        }
    }

    private void playAudio(byte[] data) {

        try {

            stopAudio();

            File file =
                    new File(
                            getCacheDir(),
                            "poetry_preview.mp3"
                    );

            FileOutputStream out =
                    new FileOutputStream(file);

            out.write(data);
            out.flush();
            out.close();

            player =
                    new MediaPlayer();

            player.setDataSource(
                    file.getAbsolutePath()
            );

            player.prepare();

            player.start();

            player.setOnCompletionListener(
                    mp -> status.setText(
                            "✓ آواز مکمل ہو گئی"
                    )
            );

        } catch (Exception e) {

            status.setText(
                    "⚠ آواز چل نہیں سکی"
            );
        }
    }

    private void stopAudio() {

        try {

            if (player != null) {

                if (player.isPlaying()) {
                    player.stop();
                }

                player.release();
                player = null;
            }

        } catch (Exception ignored) {
        }

        status.setText("■ آواز روک دی گئی");
    }

    private String readStream(InputStream in)
            throws Exception {

        if (in == null) return "";

        BufferedReader reader =
                new BufferedReader(
                        new InputStreamReader(
                                in,
                                "UTF-8"
                        )
                );

        StringBuilder result =
                new StringBuilder();

        String line;

        while ((line = reader.readLine()) != null) {
            result.append(line);
        }

        reader.close();

        return result.toString();
    }

    private byte[] readBytes(InputStream in)
            throws Exception {

        ByteArrayOutputStream out =
                new ByteArrayOutputStream();

        byte[] buffer =
                new byte[8192];

        int count;

        while ((count = in.read(buffer)) != -1) {
            out.write(buffer, 0, count);
        }

        in.close();

        return out.toByteArray();
    }

    private LinearLayout card() {

        LinearLayout box =
                new LinearLayout(this);

        box.setOrientation(
                LinearLayout.VERTICAL
        );

        box.setPadding(
                16, 16, 16, 16
        );

        GradientDrawable drawable =
                new GradientDrawable();

        drawable.setColor(cardBg);
        drawable.setCornerRadius(22);

        box.setBackground(drawable);

        return box;
    }

    private TextView title(
            String value,
            int size
    ) {

        TextView t =
                new TextView(this);

        t.setText(value);
        t.setTextColor(text);
        t.setTextSize(size);
        t.setTypeface(
                Typeface.DEFAULT_BOLD
        );

        t.setPadding(
                0, 4, 0, 10
        );

        return t;
    }

    private TextView label(
            String value,
            int size
    ) {

        TextView t =
                new TextView(this);

        t.setText(value);
        t.setTextColor(subText);
        t.setTextSize(size);

        t.setPadding(
                0, 5, 0, 7
        );

        return t;
    }

    private EditText edit(
            String hint,
            boolean multi
    ) {

        EditText e =
                new EditText(this);

        e.setHint(hint);
        e.setHintTextColor(
                Color.rgb(125, 125, 140)
        );

        e.setTextColor(Color.WHITE);
        e.setTextSize(17);

        e.setPadding(
                14, 12, 14, 12
        );

        e.setBackgroundColor(
                Color.rgb(38, 38, 48)
        );

        if (multi) {

            e.setSingleLine(false);

            e.setInputType(
                    android.text.InputType.TYPE_CLASS_TEXT |
                    android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE
            );
        }

        return e;
    }

    private Button action(
            String value,
            int color
    ) {

        Button b =
                new Button(this);

        b.setText(value);
        b.setTextColor(Color.WHITE);
        b.setTextSize(15);
        b.setAllCaps(false);

        GradientDrawable drawable =
                new GradientDrawable();

        drawable.setColor(color);
        drawable.setCornerRadius(18);

        b.setBackground(drawable);

        return b;
    }

    private Space space(int height) {

        Space s =
                new Space(this);

        s.setLayoutParams(
                new LinearLayout.LayoutParams(
                        1,
                        height
                )
        );

        return s;
    }

    @Override
    protected void onDestroy() {

        stopAudio();

        super.onDestroy();
    }
}